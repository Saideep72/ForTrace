import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import NetworkAnalysis from './pages/NetworkAnalysis';
import AIChat from './pages/AIChat';
import Settings from './pages/Settings';
import OperationsCenter from './pages/OperationsCenter';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/network" element={<NetworkAnalysis />} />
        <Route path="/ai" element={<AIChat />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/operations" element={<OperationsCenter />} />
        <Route path="/assets" element={<Navigate to="/operations" replace />} />
        <Route path="/documents" element={<Navigate to="/operations" replace />} />
        <Route path="/reports" element={<Navigate to="/operations" replace />} />
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
